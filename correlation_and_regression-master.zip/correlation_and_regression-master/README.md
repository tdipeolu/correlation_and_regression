This repo contains data and code for my 11.03.2020 Towards Data Science article titled "Evaluating linear relationships" (https://towardsdatascience.com/evaluating-linear-relationships-1d239f51297b).
